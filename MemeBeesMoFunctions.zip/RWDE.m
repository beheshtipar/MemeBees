%% *RWDE: Random Walk with Direction Exploitation*

% Created on May 11 2017
% By Muhammad Asif

% Random Walk with Direction Exploitation(RWDE)
% Second Deterministic Short-distance exploration, used to find the local optimum around the best solution

% From "Memetic Artificial Bee Colony Algorithm for Large-Scale Global
% Optimization" by Fister et al.

%Inspired from Engineering Optimization: Theory and Practice by SS Rao

%%					*Function I/O*

% *Input: *
% * *Solution*: The position of the candidate solution to be improved. Passed as a vector.
% * *dim*: The number of variables
% * *step*: The Starting Random Walk Distance
% * *minstep*: Minimum walking distance
% * *N*: Maximum Number of iterations with no improvement before switching to a smaller step size


% *Output: *
% * *newSolution*: The improved solution's position. Passed as a 1bydim vector
% * *Fitness is the fitness value of the new solution


%% Source Code
function [newSolution, Fitness] = RWDE(Solution, dim, step, minstep, N )


Xprev= Solution; %Initial Guess
Fprev = objFun(Xprev); %Initial Function Value

%% 
%Diagnostic variables
fcalls=0;
fhistory = []; 

%% 
%Main Loop

while (step>minstep)
    i=1;
    while i<=N
        
        %%
		%Generate random vector with dim elements with range between 1 and -1
        u= rand(1,dim).*(1-(-1))+(-1.*(ones(1,dim)));
        
         %if(norm(u)>1) %to avoid bias
            %continue %regenerate the random vector
         %end
        
		%%
		% Normalize to unit vector
        u = u.*(1/norm(u)); 
        X= Xprev+step.*(u);
        F = objFunc(X);
        fcalls= fcalls+1;
        
        %%
		%Compare
        if (F<Fprev)
            %%
			%Direction Exploitation Step. See..[Insert Link]
			[exploitedstep, fmorecalls] = directionExploit(Xprev,u,step,minstep);
            
            fcalls = fcalls+fmorecalls;
            
            X = Xprev+exploitedstep.*(u);
            F = objFunc(X);
            
            fhistory(length(fhistory)+1)=F;
            
            Xprev= X;
            Fprev= F;
            i=1;
        else
            i= i+1;
        end
    end
    
    step = step/2;
    
    
end

%%
%Pass these variables out
newSolution= Xprev;
Fitness = FPrev;

end





